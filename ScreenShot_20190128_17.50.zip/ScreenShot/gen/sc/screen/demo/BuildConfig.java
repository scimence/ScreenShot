/** Automatically generated file. DO NOT MODIFY */
package sc.screen.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}