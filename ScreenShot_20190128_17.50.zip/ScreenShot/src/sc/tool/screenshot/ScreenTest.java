
package sc.tool.screenshot;

import sc.tool.screenshot.ScreenActivity.ScreenCallBack;
import android.content.Context;

public class ScreenTest
{
	/** 截屏测试逻辑 */
	public static void Init(Context context)
	{
		// 请求允许获取屏幕，用允许时截屏保存
		ScreenActivity.Init(context, new ScreenCallBack()
		{
			@Override
			public void Success()
			{
				// ScreenActivity.GetScreen(); 		// 截屏保存
				ScreenActivity.GetScreen(5000, 12);	// 投影截屏（延时多次截屏）
			}
		});
	}
	
	/** 录屏测试逻辑 */
	public static void InitVedio(Context context)
	{
		// 请求允许获取屏幕，用允许时截屏保存
		ScreenActivity.Init(context, new ScreenCallBack()
		{
			@Override
			public void Success()
			{
				// ScreenActivity.GetVedio_Start();		// 开始录屏
				// ScreenActivity.GetVedio_Stop();		// 停止录屏
				ScreenActivity.GetVedio(3000L, 3 * 60 * 1000L);	// 投影录屏（3秒后开始录屏，录取3分钟视屏后停止录制）
			}
		});
	}
}
