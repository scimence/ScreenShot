﻿
package sc.tool.crash;

import android.app.Application;


public class LtsdkApplication extends Application
{
	public void onCreate()
	{
		super.onCreate();
		
		// 捕获App运行异常信息
		CrashHandler handler = CrashHandler.getInstance();
		handler.init(getApplicationContext());
	}
	
}
